package assignment;

public class Staff {

	public void addEmployee(Employee worker) {
	}

	/**
	 * 
	 * @return newline-seperated String of all StudentWorkers
	 */
	public String toStringOnlyStudentWorkers() {
		return "";
	}

	/**
	 * 
	 * @return newline-seperated String of all TempWorkers
	 */
	public String toStringOnlyTempWorkers() {
		return "";
	}

	/**
	 * 
	 * @return sum of all employees' calcPay
	 */
	public double calcPayForAllEmployees() {
		return -1.0;
	}
}
